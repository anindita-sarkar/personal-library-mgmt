# todo-app
Simple TODO list app using Node.js, Express and MySQL
